import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;


public class EmployeeProperty {

	private static Properties createDefaultProperties() {

		Properties tempProp = new Properties();
		/* Database connection parameter properties are set */
		tempProp.setProperty("ID","101");
		tempProp.setProperty("Name", "Gunjan");
		tempProp.setProperty("Salary", "300000");
		tempProp.setProperty("Designation", "Manager");
		tempProp.setProperty("Insurance_Scheme", "Scheme A");
		return tempProp;
	}
	
	private static Properties loadProperties(String fileName) {

		InputStream propsFile;
		Properties tempProp = new Properties();

		try {
			propsFile = new FileInputStream(fileName);
			tempProp.load(propsFile);
			propsFile.close();
		} catch (IOException ioe) {
			System.out.println("I/O Exception.");
			ioe.printStackTrace();
			System.exit(0);
		}
		return tempProp;
	}
	
	private static void saveProperties(Properties p, String fileName) {
		OutputStream propsFile;

		try {
			propsFile = new FileOutputStream(fileName);
			p.store(propsFile, "Properties File to the Test Application");
			propsFile.close();
		} catch (IOException ioe) {
			System.out.println("I/O Exception.");
			ioe.printStackTrace();
			System.exit(0);
		}

	}
	
	private static void printProperties(Properties p, String s) {
		System.out.println();
		System.out.println("========================================");
		System.out.println(s);
		System.out.println("========================================");
		System.out.println("+---------------------------------------+");
		System.out.println("| Print Application Properties          |");
		System.out.println("+---------------------------------------+");
		p.list(System.out);
		System.out.println();
	}
	
	public static void main(String[] args) {
		
		final String PROPFILE = "PersonProps.properties";
		Properties myProp;
		Properties myNewProp;
		
		myProp = createDefaultProperties();
		saveProperties(myProp, PROPFILE);
		myNewProp = loadProperties(PROPFILE);
		printProperties(myNewProp, "Loaded Properties");
	}

}
