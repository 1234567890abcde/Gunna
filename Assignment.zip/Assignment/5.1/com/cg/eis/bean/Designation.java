package com.cg.eis.bean;

public enum Designation {
	System_Associate,Programmer,Manager,Clerk
}
