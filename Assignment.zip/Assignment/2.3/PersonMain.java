public class PersonMain {

	public static void main(String[] args) {
		
		String fname;
		String lname;
		char gender;
		
		Person person = new Person("Gunjan","Agarwal",'F');
		
		person.output();
	}
}