
public class AccountHolder {

	public static void main(String[] args) {
		
		Person person1 = new Person("Smith",".",Gender.M);
		Person person2 = new Person("kathy",".",Gender.F);
		
		Account accountPerson1 = new SavingsAccount(2000,person1);
		Account accountPerson2 = new CurrentAccount(3000,person2);
		
		//Before update
		System.out.println("------------ Before Update ------------------");
		/*accountPerson1.output();
		accountPerson2.output();*/
		System.out.println(accountPerson1);
		System.out.println(accountPerson2);
		
		accountPerson1.deposit(2000);		
		boolean statusWithdraw = accountPerson2.withdraw(2700);
		
		
		//After Update
		System.out.println("------------- After Update -------------------");
		/*accountPerson1.output();
		accountPerson2.output();*/
		System.out.println(accountPerson1);
		if(statusWithdraw){
			System.out.println(accountPerson2);
		}else{
			System.out.println("You cannot withdraw the amount because your transaction is crossing the limit");
		}
		
	}

}
