package com.cg.employee.dao;

import java.util.HashMap;

import com.cg.employee.beans.Employee;

public class EmployeeDAOImpl implements IEmployeeDAO {

	private HashMap<Integer, Employee> empList;
	
	
	

	public HashMap<Integer, Employee> getEmpList() {
		return empList;
	}




	public void setEmpList(HashMap<Integer, Employee> empList) {
		this.empList = empList;
	}




	@Override
	public Employee getEmployee(int empId) {
		Employee emp = empList.get(empId);
		return emp;
	}

}
