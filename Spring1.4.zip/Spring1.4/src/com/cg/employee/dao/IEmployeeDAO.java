package com.cg.employee.dao;

import com.cg.employee.beans.Employee;

public interface IEmployeeDAO {
	public Employee getEmployee(int empId);
}
