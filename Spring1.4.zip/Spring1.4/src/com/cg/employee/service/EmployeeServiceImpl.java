package com.cg.employee.service;

import com.cg.employee.beans.Employee;
import com.cg.employee.dao.IEmployeeDAO;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDAO employeeDAO;
	
	public IEmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(IEmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	@Override
	public Employee getEmployee(int empId) {
		Employee emp = employeeDAO.getEmployee(empId);
		return emp;
	}

}
