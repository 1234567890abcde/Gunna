package com.cg.employee.service;

import com.cg.employee.beans.Employee;

public interface IEmployeeService {

	public Employee getEmployee(int empId);
}
