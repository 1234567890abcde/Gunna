package com.cg.employee.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.employee.beans.Employee;
import com.cg.employee.service.EmployeeServiceImpl;
import com.cg.employee.service.IEmployeeService;

public class EmployeeClient {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
		IEmployeeService service = (EmployeeServiceImpl)ctx.getBean("serviceImpl");
		Employee emp = service.getEmployee(12345);
		System.out.println(emp);
	}

}
